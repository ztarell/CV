import cv2
import numpy as np
import sys

# read arguments
if(len(sys.argv) != 7) :
    print(sys.argv[0], ": takes 6 arguments. Not ", len(sys.argv)-1)
    print("Expecting arguments: w1 h1 w2 h2 ImageIn ImageOut.")
    print("Example:", sys.argv[0], " 0.2 0.1 0.8 0.5 fruits.jpg out.png")
    sys.exit()

w1 = float(sys.argv[1])
h1 = float(sys.argv[2])
w2 = float(sys.argv[3])
h2 = float(sys.argv[4])
name_input = sys.argv[5]
name_output = sys.argv[6]

# check the correctness of the input parameters
if(w1<0 or h1<0 or w2<=w1 or h2<=h1 or w2>1 or h2>1) :
    print(" arguments must satisfy 0 <= w1 < w2 <= 1, 0 <= h1 < h2 <= 1")
    sys.exit()

inputImage = cv2.imread(name_input, cv2.IMREAD_COLOR)
if(inputImage is None) :
    print(sys.argv[0], ": Failed to read image from: ", name_input)
    sys.exit()

# read image
cv2.imshow("input image: " + name_input, inputImage)

# change w1, w2, h1, h2 to pixel locations 
rows, cols, bands = inputImage.shape # bands == 3
W1 = round(w1*(cols-1))
H1 = round(h1*(rows-1))
W2 = round(w2*(cols-1))
H2 = round(h2*(rows-1))

# The transformation should be applied only to
# the pixels in the W1,W2,H1,H2 range.
# The following code goes over these pixels
tmp1 = np.copy(inputImage)

for i in range(H1, H2+1) :
    for j in range(W1, W2+1) :
        b, g, r = inputImage[i, j]
        gray = round(0.3*r + 0.6*g + 0.1*b + 0.5)
        tmp1[i, j] = [gray, gray, gray]

# Slicing can be used to create the same thing
# Example for zeroing out red channel
tmp2 = np.copy(inputImage)
height = H2 - H1 + 1
width = W2 -W1 + 1
zeropart = np.zeros((height, width))
tmp2[H1: H2+1, W1: W2+1, 1] = zeropart

cv2.namedWindow('replace_gray', cv2.WINDOW_AUTOSIZE)
cv2.imshow('replace_gray', tmp1)
cv2.namedWindow('remove green', cv2.WINDOW_AUTOSIZE)
cv2.imshow('remove green', tmp2)

# saving the output - example is for grey one
cv2.imwrite(name_output, tmp1)

# wait for key to exit
cv2.waitKey(0)
cv2.destroyAllWindows()



