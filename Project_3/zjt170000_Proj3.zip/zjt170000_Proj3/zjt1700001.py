import cv2
import numpy as np
import sys

# read arguments
if(len(sys.argv) != 8) :
    print(sys.argv[0], ": takes 7 arguments. Not ", len(sys.argv)-1)
    print("Expecting arguments: Image f u0 v0 a b c")
    print("Example:", sys.argv[0], "fruits.jpg 1.0 255.0 240.0 0.0003 0.0 0.6")
    sys.exit()

name_input = sys.argv[1]
f = float(sys.argv[2])
u0 = float(sys.argv[3])
v0 = float(sys.argv[4])
a = float(sys.argv[5])
b = float(sys.argv[6])
c = float(sys.argv[7])


# read image
inputImage = cv2.imread(name_input, cv2.IMREAD_COLOR)
if(inputImage is None) :
    print(sys.argv[0], ": Failed to read image from: ", name_input)
    sys.exit()
cv2.imshow("input image: " + name_input, inputImage)

h, w, channels = inputImage.shape
print ("f = " ,f,"u0 = ",u0,"v0 = ",v0,"a = ", a,"b = ",b,"c = ",c)
print ("Height = ", h, "Width = ",w)

dst = np.array([
	[0, 0],
	[0, h],
	[w, 0],
	[w, h]], dtype = "float32")
#Point 0,0
X0 = (c*(-u0))/(f-(a*(-u0)))-(b*(-v0))
Y0 = (c*(-v0))/(f-(a*(-u0)))-(b*(-v0))

#Point w,0
X1 = (c*(w-u0))/(f-a*(w-u0)-(b*(-v0)))
Y1 = (c*(-v0))/(f-a*(w-u0)-(b*(-v0)))

#Point 0,h
X2 = (c*(-u0))/(f-a*(-u0)-(b*(h-v0)))
Y2 = (c*(h-v0))/(f-a*(-u0)-(b*(h-v0)))

#Point w,h
X3 = (c*(w-u0))/(f-a*(w-u0)-(b*(h-v0)))
Y3 = (c*(h-v0))/(f-a*(w-u0)-(b*(h-v0)))

input_pts=np.float32([[0,0],[w,0],[0,h],[w,h]])
output_pts = np.float32([[X0+u0,Y0+v0],[X1+u0,Y1+v0],[X2+u0,Y2+v0],[X3+u0,Y3+v0]])

M = cv2.getPerspectiveTransform(input_pts,output_pts)
out  = cv2.warpPerspective(inputImage,M,(inputImage.shape[0],inputImage.shape[1]),flags=cv2.INTER_LINEAR)
cv2.imshow("Output", out)

# wait for key to exit
cv2.waitKey(0)
cv2.destroyAllWindows()
