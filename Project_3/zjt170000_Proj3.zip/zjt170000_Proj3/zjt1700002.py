import cv2
import numpy as np
import sys

# read arguments
if(len(sys.argv) != 3) :
    print(sys.argv[0], ": takes 2 arguments. Not ", len(sys.argv)-1)
    print("Expecting arguments: Image c")
    print("Example:", sys.argv[0], " fruits.jpg 0.5")
    sys.exit()

name_input = sys.argv[1]
c = float(sys.argv[2])

# read image
inputImage = cv2.imread(name_input, cv2.IMREAD_COLOR)
if(inputImage is None) :
    print(sys.argv[0], ": Failed to read image from: ", name_input)
    sys.exit()
cv2.imshow("input image: " + name_input, inputImage)

h, w, channels = inputImage.shape
print ("c = ",c)
print ("Width = ",w, "Height = ", h)

u0 = 255.0
v0 = 240.0
f = 1.0
a = -0.001
b = 0.0
print (u0, v0)
dst = np.array([
	[0, 0],
	[0, h],
	[w, 0],
	[w, h]], dtype = "float32")
#Point 0,0
X0 = (c*(-u0))/(f-(a*(-u0)))-(b*(-v0))
Y0 = (c*(-v0))/(f-(a*(-u0)))-(b*(-v0))

#Point w,0
X1 = (c*(w-u0))/(f-a*(w-u0)-b*(-v0))
Y1 = (c*(-v0))/(f-a*(w-u0)-b*(-v0))

#Point 0,h
X2 = (c*(-u0))/(f-a*(-u0)-b*(h-v0))
Y2 = (c*(h-v0))/(f-a*(-u0)-b*(h-v0))

#Point w,h
X3 = (c*(w-u0))/(f-a*(w-u0)-b*(h-v0))
Y3 = (c*(h-v0))/(f-a*(w-u0)-b*(h-v0))

input_pts=np.float32([[0,0],[w,0],[0,h],[w,h]])
output_pts = np.float32([[X0+u0,Y0+v0],[X1+u0,Y1+v0],[X2+u0,Y2+v0],[X3+u0,Y3+v0]])

M = cv2.getPerspectiveTransform(input_pts,output_pts)
out  = cv2.warpPerspective(inputImage,M,(inputImage.shape[0],inputImage.shape[1]),flags=cv2.INTER_LINEAR)
cv2.line(out,(256,0),(256,480), (0,255,0), thickness=1)
cv2.imshow("Veritcal Line", out)

#IMAGE 2
u1 = 255.0
v1 = 240.0
f1 = 1.0
a1 = 0.000
b1 = 0.0015
dst1 = np.array([
	[0, 0],
	[0, h],
	[w, 0],
	[w, h]], dtype = "float32")
#Point 0,0
X01 = (c*(-u1))/(f1-(a1*(-u1)))-(b1*(-v1))
Y01 = (c*(-v1))/(f1-(a1*(-u1)))-(b1*(-v1))

#Point w,0
X11 = (c*(w-u1))/(f1-a1*(w-u1)-b1*(-v1))
Y11 = (c*(-v1))/(f1-a1*(w-u1)-b1*(-v1))

#Point 0,h
X21 = (c*(-u1))/(f1-a1*(-u1)-b1*(h-v1))
Y21 = (c*(h-v1))/(f1-a1*(-u1)-b1*(h-v1))

#Point w,h
X31 = (c*(w-u1))/(f1-a1*(w-u1)-b1*(h-v1))
Y31 = (c*(h-v1))/(f1-a1*(w-u1)-b1*(h-v1))
inputImage2 = inputImage.copy()

input_pts2=np.float32([[0,0],[w,0],[0,h],[w,h]])
output_pts2 = np.float32([[X01+u1,Y01+v1],[X11+u1,Y11+v1],[X21+u1,Y21+v1],[X31+u1,Y31+v1]])
M2 = cv2.getPerspectiveTransform(input_pts2,output_pts2)
out2  = cv2.warpPerspective(inputImage2,M2,(inputImage.shape[0],inputImage.shape[1]),flags=cv2.INTER_LINEAR)
cv2.line(out2,(0,240),(512,240), (0,255,0), thickness=1)
cv2.imshow("Horizontal Line",out2)

# wait for key to exit
cv2.waitKey(0)
cv2.destroyAllWindows()